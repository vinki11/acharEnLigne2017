USE [ASPNET2014-LEGAREFRANCOIS]

SET IDENTITY_INSERT [dbo].[page] ON

INSERT [dbo].[page] ([page_id], [page_url], [page_titre], [page_description], [page_keywords], [page_h1], [page_texte], [page_public]) VALUES (16, N'404.aspx', N'404', N'Page d''erreur affich�e lorsque la page recherch�e est introuvable.', N'Informatique, vente en ligne, francophone, pi�ces d''ordinateur, carte graphique, carte m�re, performance, processeur, bas prix, ordinateur', N'Page introuvable', N'D�sol� mais la page que vous recherchez n''existe pas ou est indisponible. ', 1)
INSERT [dbo].[page] ([page_id], [page_url], [page_titre], [page_description], [page_keywords], [page_h1], [page_texte], [page_public]) VALUES (17, N'GestionCommentaires.aspx', N'Commentaires', N'Liste de tous les commentaires du site.', N'Informatique, vente en ligne, francophone, pi�ces d''ordinateur, carte graphique, carte m�re, performance, processeur, bas prix, ordinateur', N'Gestion des commentaires', N'<p>Voici tous les commentaires pr�sents sur le site.</p>', 1)

SET IDENTITY_INSERT [dbo].[page] OFF

UPDATE [dbo].[page] SET [page_texte] = '<p>Ce site a &eacute;t&eacute; d&eacute;velopp&eacute; dans le cadre d''un cours au c&eacute;gep de Victoriaville par Fran&ccedil;ois L&eacute;gar&eacute;. Aucun produit sur ce site n''est r&eacute;ellement en vente.  Veuillez noter que les fiches des produits sont pr�sentement indisponibles.  Les ventes �clairs si-dessous ne sont l� qu''� titre d''exemple.  Merci de votre compr�hension.</p>' WHERE [page_id] = 1;