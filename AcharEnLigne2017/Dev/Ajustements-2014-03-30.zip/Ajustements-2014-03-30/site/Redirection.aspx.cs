﻿/*
 * Description : Ficher de code de la page de redirection
 * Programmé par : François Légaré
 * Le : 25 février 2014
 * Historique des modifications
 * Par :
 * Le :
 * Modifications :
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Redirection : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}