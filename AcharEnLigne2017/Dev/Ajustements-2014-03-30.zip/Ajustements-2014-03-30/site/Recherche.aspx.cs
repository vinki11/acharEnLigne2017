﻿/*
 * Description : Ficher de code de la page de recherche du site
 * Programmé par : François Légaré
 * Le : 29 janvier 2014
 * Historique des modifications
 * Par :
 * Le :
 * Modifications :
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Recherche : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}