﻿/*
 * Description : Ficher de code de la page d'ajout de produit
 * Programmé par : François Légaré
 * Le : 28 février 2014
 * Historique des modifications
 * Par :
 * Le :
 * Modifications :
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AjoutProduit : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["usager_root"] == null || (bool)Session["usager_root"] != true)
        {
            String urlComplete = Request.Url.AbsoluteUri;
            String[] urlSepare = urlComplete.Split('/');
            urlSepare[urlSepare.Length - 1] = "Redirection.aspx";
            String urlRedirect = urlSepare[0];

            for (int i = 1; i < urlSepare.Length; i++)
            {
                urlRedirect += "/";
                urlRedirect += urlSepare[i];
            }

            Response.Redirect(urlRedirect.ToString());

        }
        if (!IsPostBack) //check if the webpage is loaded for the first time.
        {
            ViewState["PreviousPage"] = Request.UrlReferrer;//Saves the Previous page url in ViewState

            if (ViewState["PreviousPage"] != null)
            {
                String urlComplete = Request.UrlReferrer.AbsoluteUri;
                String[] urlSepare = urlComplete.Split('/');
                String pageActuelle = urlSepare[urlSepare.Length - 1];

                Session["url_page_prec"] = pageActuelle;
            }
            else
            {
                Session["url_page_prec"] = "Default.aspx";
            }

        }
    }
    protected void detailsViewAjout_ItemInserted(object sender, DetailsViewInsertedEventArgs e)
    {

        if (e.Exception == null)
        {
            String urlComplete = Request.Url.AbsoluteUri;
            String[] urlSepare = urlComplete.Split('/');
            urlSepare[urlSepare.Length - 1] = "ListeProduit.aspx";
            String urlRedirect = urlSepare[0];

            for (int i = 1; i < urlSepare.Length; i++)
            {
                urlRedirect += "/";
                urlRedirect += urlSepare[i];
            }

            Response.Redirect(urlRedirect.ToString());
        }
        else
        {
            // cette instruction est essentielle pour ne pas que le programme plante
            e.ExceptionHandled = true;

            labelMessage.Text = "Un problème a empêché l'ajout de données.";
            labelMessage.Visible = true;
        }
        
        
    }
    protected void detailsViewAjout_ItemCommand(object sender, DetailsViewCommandEventArgs e)
    {
        if (e.CommandName.Equals("cancel", StringComparison.CurrentCultureIgnoreCase))
        {
            if (ViewState["PreviousPage"] != null)	//Check if the ViewState contains Previous page URL
            {
                Response.Redirect(ViewState["PreviousPage"].ToString());//Redirect to previous page by retrieving the PreviousPage Url from ViewState.
            }
        }
    }
}
