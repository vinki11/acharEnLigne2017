﻿/*
 * Description : Ficher de code de la page de liste de produit
 * Programmé par : François Légaré
 * Le : 3 février 2014
 * Historique des modifications
 * Par :
 * Le :
 * Modifications :
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ListeProduit : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (dropDownListCategories.SelectedIndex == 0)
        {
            SqlDataSourceProduit.FilterExpression = "";
        }
        
    }

    protected void GridViewProduits_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        if (e.NewValues["produit_prix"] != null)
        {
            // Transforme la chaîne en une valeur décimale.
            // Enlève le signe monétaire s'il était présent.
            // Transforme le séparateur de décimales, selon la culture utilisée, en point.
            e.NewValues["produit_prix"] = decimal.Parse(e.NewValues["produit_prix"].ToString(), System.Globalization.NumberStyles.Currency);
        }
    }

    protected void GridViewProduits_RowUpdated(object sender, GridViewUpdatedEventArgs e)
    {
        if(e.Exception == null)
        {
            labelMessage.Text = "Les données ont été enregistrées avec succès.";
        }
        else
        {
            // cette instruction est essentielle pour ne pas que le programme plante
            e.ExceptionHandled = true;  
 
            labelMessage.Text = "Un problème a empêché l'enregistrement des données.";
        }
        labelMessage.Visible = true;
    }

    protected void GridViewProduits_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (Session["usager_root"] == null || (bool)Session["usager_root"] != true)
        {
            e.Row.Cells[0].Visible = false;
            labelAjout.Visible = false;
        }
        else
        {
            e.Row.Cells[0].Visible = true;
            labelAjout.Visible = true;
        }
        
    }
}