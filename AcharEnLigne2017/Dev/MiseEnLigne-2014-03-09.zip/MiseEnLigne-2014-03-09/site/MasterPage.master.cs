﻿/*
 * Description : Ficher de code de la page maître du site
 * Programmé par : François Légaré
 * Le : 3 février 2014
 * Historique des modifications
 * Par :
 * Le :
 * Modifications :
 */

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Page_Init()
    {

        this.Page.MaintainScrollPositionOnPostBack = true;

        String urlComplete = Request.Url.AbsoluteUri;
        String[] urlSepare = urlComplete.Split('/');
        String pageActuelle = urlSepare[urlSepare.Length - 1];

        Session["page_url"] = pageActuelle;

        DataView dataViewPage = (DataView)SqlDataSourcePage.Select(DataSourceSelectArguments.Empty);

        if (dataViewPage.Count > 0)
        {
            DataRowView donnees = dataViewPage[0];

            Session["commentaire_pageid"] = donnees[0];
            titrePage.Text = donnees[1].ToString();
            h1Accueil.InnerHtml = donnees[4].ToString();
            labelTextePage.Text = donnees[5].ToString();

            GridViewCommentaires.DataBind();
        }
        else
        {

        }

        if (Session["usager_UserID"] != null)
        {
            connexion();
            textBoxCommentaire.Enabled = true;
            buttonEnvoyerComm.Enabled = true;
            labelCommentaire.Text = "Laissez votre commentaire.";
            labelInscription.Text = "Votre compte";
        }
        else
        {
            labelInscription.Text = "Inscription";
            textBoxCommentaire.Enabled = false;
            buttonDeco.Visible = false;
            buttonEnvoyerComm.Enabled = false;
            labelCommentaire.Text = "Veuillez vous connecter pour laisser un commentaire.";
        }

       
    }



    protected void buttonSoumettre_Click(object sender, EventArgs e)
    {
        if (Membership.ValidateUser(textBoxUsager.Text, textBoxMdp.Text))
        {
            Session["UserName"] = textBoxUsager.Text;
            DataView dataViewUserID = (DataView)SqlDataSourceUserID.Select(DataSourceSelectArguments.Empty);
            DataRowView donnees = dataViewUserID[0];
            Session["usager_UserID"] = donnees["UserId"].ToString();
            connexion();
            ViewState["Actualisation"] = Request.Url;
            Response.Redirect(ViewState["Actualisation"].ToString());
        }
        else
        {
            labelProbleme.Visible = true;
            labelProbleme.Text = "Usager ou mot de passe incorrect.";
        }

    }
    protected void buttonDeco_Click(object sender, EventArgs e)
    {
        labelUsager.Visible = true;
        labelMdp.Visible = true;
        textBoxUsager.Visible = true;
        textBoxMdp.Visible = true;
        buttonSoumettre.Visible = true;
        labelConnexion.Visible = false;
        labelConnexion.Text = "";
        buttonDeco.Visible = false;
        Session["usager_UserID"] = null;
        ViewState["Actualisation"] = Request.Url;
        Session["usager_root"] = null;
        Response.Redirect(ViewState["Actualisation"].ToString());

    }

    protected void connexion()
    {
        labelUsager.Visible = false;
        labelMdp.Visible = false;
        textBoxUsager.Visible = false;
        textBoxMdp.Visible = false;
        buttonSoumettre.Visible = false;
        labelProbleme.Visible = false;
        labelConnexion.Visible = true;
        DataView dataViewUsager = (DataView)SqlDataSourceUsager.Select(DataSourceSelectArguments.Empty);
        DataRowView donnees = dataViewUsager[0];
        string nomcomplet = donnees[0].ToString();
        labelConnexion.Text = "Bienvenue, Monsieur " + nomcomplet + " !";
        buttonDeco.Visible = true;
        Session["usager_root"] = donnees[2];
    }

    protected void buttonEnvoyerComm_Click(object sender, EventArgs e)
    {
        if (textBoxCommentaire.Text != "")
        {
            Session["commentaire_texte"] = textBoxCommentaire.Text;
            DataView dataViewUsager = (DataView)SqlDataSourceUsager.Select(DataSourceSelectArguments.Empty);
            DataRowView donnees = dataViewUsager[0];
            Session["commentaire_usagerid"] = donnees[1];

            SqlDataSourceCommentaire.Insert();

            textBoxCommentaire.Text = "";
        }
        else
        { 
        }
    }
}
